package com.streamroulette.api.model;

public class ChannelModel {
}
