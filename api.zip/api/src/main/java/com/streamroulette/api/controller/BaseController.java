package com.streamroulette.api.controller;

public class BaseController {

}
