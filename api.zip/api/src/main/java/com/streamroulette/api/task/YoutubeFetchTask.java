package com.streamroulette.api.task;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class YoutubeFetchTask {

    @Scheduled(cron = "0 */15 * * * *")
    public void run () {
        System.out.println("Fetching Youtube Entries");
    }
}
