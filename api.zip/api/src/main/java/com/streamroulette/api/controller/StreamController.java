package com.streamroulette.api.controller;

import com.streamroulette.api.model.StreamModel;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@Res
tController
@RequestMapping("/stream")
public class StreamController {

    private final AtomicLong counter = new AtomicLong();
    private List<StreamModel> streams = new ArrayList<>();

    @RequestMapping(method = RequestMethod.GET)
    public StreamModel get(
            @RequestParam(value="name") String name,
            @RequestParam(value="test", defaultValue="", required=false) String test
    ) {
        return new StreamModel(counter.incrementAndGet());
    }

    @RequestMapping(value = "/list")
    public List<StreamModel> list (
            @RequestParam(value="name") String name
    ) {
        int l = this.streams.size();
        List<StreamModel> list = new ArrayList<>();
        StreamModel stream;

        for(int i = 0; i < l; i++) {
            stream = this.streams.get(i);

            System.out.println(name + ":" + stream.getStream_name());

            if(stream.getStream_name().equals(name)) {
                list.add(stream);
            }
        }

        return list;
    }

    //    @RequestMapping(method = RequestMethod.DELETE)
    @RequestMapping(value = "/delete")
    public String delete (
            @RequestParam(value="name") String name
    ) {
        int l = this.streams.size();
        int n = 0;
        StreamModel stream;

        for (int i = 0; i < l; i++) {
            stream = this.streams.get(i);

            if(stream.getStream_name() == name) {
                this.streams.remove(i);
                n++;
                l--;
                i--;
            }
        }
        return "Deleted " + n + " instances";
    }

    @RequestMapping(value = "/put")
    public String put (
            @RequestParam(value="name") String name
    ) {
        this.streams.add(new StreamModel(name));
        return "Created Successfully";
    }
}
