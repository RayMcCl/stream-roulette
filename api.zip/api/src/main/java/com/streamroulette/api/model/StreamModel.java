package com.streamroulette.api.model;

public class StreamModel extends BaseModel {

    private final long stream_id;
    private final String stream_name;
    private final String display_name;
    private final long views;
    private final long followers;
    private final String url;
    private final boolean partner;
    private final boolean mature;
    private final String language;

    public StreamModel (long val) {
        this.stream_id = val;
        this.stream_name = "test";
        this.display_name = "hello";
        this.views = 50;
        this.followers = 50;
        this.url = "www.google.com";
        this.partner = true;
        this.mature = true;
        this.language = "English";
    }

    public StreamModel (String val) {
        this.stream_id = 0;
        this.stream_name = val;
        this.display_name = "hello";
        this.views = 50;
        this.followers = 50;
        this.url = "www.google.com";
        this.partner = true;
        this.mature = true;
        this.language = "English";
    }

    public long getStream_id() {
        return stream_id;
    }

    public String getStream_name() {
        return stream_name;
    }

    public String getDisplay_name() {
        return display_name;
    }

    public long getViews() {
        return views;
    }

    public long getFollowers() {
        return followers;
    }

    public String getUrl() {
        return url;
    }

    public boolean isPartner() {
        return partner;
    }

    public boolean isMature() {
        return mature;
    }

    public String getLanguage() {
        return language;
    }
}
